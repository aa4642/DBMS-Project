<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 1.1.0
    </div>
    <strong>Libray Management System &nbsp;Brought To You By <a href="https://code-projects.org/"> Code-Projects</a>.</strong>
  </footer>
